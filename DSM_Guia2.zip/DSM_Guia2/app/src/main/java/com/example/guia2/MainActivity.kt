package com.example.guia2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

lateinit var num1 : EditText
lateinit var num2 : EditText
lateinit var enviar : Button
lateinit var resultado : TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1 = findViewById(R.id.TxtNum1)
        num2 = findViewById(R.id.TxtNum2)
        enviar = findViewById(R.id.BtnEnviar)
        resultado = findViewById(R.id.LlbResultado)

        enviar.setOnClickListener{
            var suma : String =  (num1.text.toString().toFloat() + num2.text.toString().toFloat()).toString()
            resultado.setText(suma)
        }
    }
}